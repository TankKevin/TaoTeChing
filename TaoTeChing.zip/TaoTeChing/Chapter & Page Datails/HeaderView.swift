//
//  HeaderView.swift
//  TaoTeChing
//
//  Created by 谭凯文 on 2018/10/2.
//  Copyright © 2018 Tan Kevin. All rights reserved.
//

import UIKit

class HeaderView: UIStackView {
    @IBOutlet var label: UILabel!
}
